/**
 * Created by bey on 28/11/16.
 */
var express = require('express');
var router = express.Router();
var Users = require('../models/Users').Users;
var mongoose = require('mongoose');
var request = require('request');
var session = require('express-session');



router.post('/signIn', function (req, res) {

    var email = req.body.email;
    var password = req.body.password;

    Users.findOne({email : email , password : password} , function (err, user) {
        if(err){//hundle the error
            console.log(err)
            return res.status(500).send();
        }else if (!user){//user not found
            return res.status(404).send();
        }
        //req.session.user = user ; 
        return res.status(200).send(user);

    })
    
});

module.exports = router;
