/**
 * Created by bey on 28/11/16.
 */
var express = require('express');
var router = express.Router();
var UserManager = require('user-manager');
var request = require('request');
var Users = require('../models/Users').Users;
var validator = require('validator');
var moment = require('moment');
//var isDate = require('lodash.isdate');
//var date_validator = require("Datevalidator").DateValidator;
router.post('/signUp', function (req, res) {
//console.log('req.body.birthday'+moment("06/22/2015", "MM/DD/YYYY", true).isValid())

       /* var email = req.body.email;
        var password = req.body.password;
        var firstName = req.body.firstName;
        var lastName = req.body.lastName;
        var birthday = req.body.birthday;
        var gender = req.body.gender;*/

    //var usermanager = new UserManager;
    
    //check all required parameters
   if((typeof req.body.email != 'undefined')&&(typeof req.body.password != 'undefined')&&(typeof req.body.firstName !='undefined')&&(typeof req.body.lastName !='undefined')) {
       //check email type
       if(validator.isEmail(req.body.email)){
           //check birthday type
           if(moment(req.body.birthday, "MM/DD/YYYY", true).isValid()){
               //check gender type
               if((req.body.gender =='male')||(req.body.gender == 'female')){
                   //create user using user-manager module
                   var userManager = new UserManager();
                   var createdUser = userManager.createUser(req,res);

                   if(error){
                       res.json(200, {error: {"code": 100, "message": "invalid user"}, instatus: 2160, success: '0'});
                   }else{return createdUser;}

               }else{

                   var error = {
                       "code": 101,
                       "message": "invalid parametre value 'gender': must be Male or Female."
                       
                   }
               }
           }else {
               res.json(200, {error: {"code": 100, "message": "invalid date format"}, instatus: 2160, success: '0'});

            }
           }else{
           res.json(200, {error: {"code": 100, "message": "invalid email format"}, instatus: 2160, success: '0'});
           }


   }else{
       return res.status(200).json({error: {"code": 100,"message": "missing parametre"}, instatus: 2160, success : '0'});
    }
});

module.exports = router;
