/**
 * Created by bey on 05/12/16.
 */
var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var UserManager = require('user-manager');
var session = require('express-session');
var Users = require('../models/Users').Users;


router.get('/dashboard', function (req, res) {
    
    if(!req.session.user){
        return res.status(401).send();
    }
    
    
    
});
