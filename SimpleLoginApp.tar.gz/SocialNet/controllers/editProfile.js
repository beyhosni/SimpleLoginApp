/**
 * Created by bey on 28/11/16.
 */

var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var UserManager = require('user-manager');
var moment = require('moment');
var validator = require('validator');
var Users = require('../models/Users').Users;

router.post('/editProfile', function (req, res) {
   
    
    if((typeof req.body.password != 'undefined')&&(typeof req.body.firstName !='undefined')&&(typeof req.body.lastName !='undefined')) {
        
            //check birthday type
            if(moment(req.body.birthday, "MM/DD/YYYY", true).isValid()){
                //check gender type
                if((req.body.gender =='male')||(req.body.gender == 'female')){
                     // update user using user-manager module

                    var userManager = new UserManager();
                    var updatedUser = userManager.updateUser(req,res);
                    if(error){
                        res.json(200, {error: {"code": 100, "message": "invalid user upadate"}, instatus: 2160, success: '0'});
                    }else{return updatedUser;}
                }else{
                    var error = {
                        "code": 101,
                        "message": "invalid parametre value 'gender': must be Male or Female."
                    }
                }
            }else {
                res.json(200, {error: {"code": 100, "message": "invalid date format"}, instatus: 2160, success: '0'});

            }
    }else{
        return res.status(200).json({error: {"code": 100,"message": "missing parametre"}, instatus: 2160, success : '0'});
    }

});

module.exports = router;
    
    
    
    
