module.exports = {
    'url' : 'mongodb://localhost:27017/User_schema',
    'pathHTTP' : 'http://',
    'pathServer' : 'localhost',
    //'pathServer' : 'localhost',
    'portServer' : ':3000',
    'secret': 'secret',
}